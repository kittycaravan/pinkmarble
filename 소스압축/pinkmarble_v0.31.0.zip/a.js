const VERSION = "pinkmarble_v0.31.0";
const LANDS = ["시작","고양","창원","무인도","울산","수원","우주왕복선","대구","인천","국민연금","부산","서울"];

let players = [];    // 플레이어 객체 배열
let disp;   // 디스플레이 객체
let lands = []; // 땅 객체 배열

let logText = "";       // 텍스트에어리어 내에 표현되는 텍스트를 계속 누적시킬 용도의 텍스트변수;
let currentPlayerTurn = 1;  // 현재 어떤 플레이어의 차례인지 표시하는 변수
let player1Lands = [];
let player2Lands = [];
let landCanBuy = [2,3,5,6,8,9,11,12];   // 구매 가능한 땅 번호 배열
let landValues = [20,10,20,0,30,40,30,50,60,30,80,100];   // 땅 순서대로 땅값 또는 내거나 받을 돈을 나열한 배열

window.onload = function(){
    init(); //각종 초기화 처리들
    disp.displayPlayersGold(players);
}

function dice(){
    let diceValue = Math.floor(Math.random()*6+1);
    log(`플레이어 ${currentPlayerTurn}(이)가 주사위를 굴려 ${diceValue} (이)가 나왔습니다.`);

    procMove(diceValue);    // 나온 주사위 값을 전달하고 이동으로 인한 모든 처리를 수행

    disp.displayPlayersGold(players);   // 금액 표시 갱신
    procTurnPass(currentPlayerTurn);    // 플레이어 턴 넘김 처리
    checkGameover();
}

function init(){
    lands.push(new Land("시작",20));
    lands.push(new Land("고양",10));
    lands.push(new Land("창원",20));
    lands.push(new Land("무인도",0));
    lands.push(new Land("울산",30));
    lands.push(new Land("수원",40));
    lands.push(new Land("우주왕복선",0));
    lands.push(new Land("대구",50));
    lands.push(new Land("인천",60));
    lands.push(new Land("국민연금",30));
    lands.push(new Land("부산",80));
    lands.push(new Land("서울",100));
    disp = new Disp();
    disp.init();
    players.push(new Player('😻','red'));
    players.push(new Player('🐺','blue'));
}

function checkGameover(){
    if(players[0].gold<=0){
        disp.diceBtnAllDisable();
        log("게임오버! 플레이어 2가 이겼습니다.");
    }         
    if(players[1].gold<=0){
        disp.diceBtnAllDisable();
        log("게임오버! 플레이어 1이 이겼습니다.");
    }         
}

function procTurnPass(playerNumber){
    if(playerNumber == 1){   // 플레이어 1이 주사위를 다 굴린 후 처리들
        currentPlayerTurn = 2;  // 현재 플레이어를 2로 바꿈
    } else if(playerNumber == 2) {    // 플레이어 2가 주사위를 다 굴린 후 처리들
        currentPlayerTurn = 1;  // 현재 플레이어를 2로 바꿈
    }
    disp.diceBtnToggle(currentPlayerTurn);
}

function payGoldToBank(player,gold){    // 은행에 납부는 플레이어 골드 함수의 골드를 - 로 바꿔 전달해서 처리함.
    playerGoldPlusMinus(player,-gold);
}

function payGoldToPlayer(fromPlayer,toPlayer,gold){ // 주의: 지불할 금액은 양수로 넣게했음.
    playerGoldPlusMinus(fromPlayer,-gold);
    playerGoldPlusMinus(toPlayer,gold);
}

function playerGoldPlusMinus(player,gold){
    switch(player){
        case 1:
            players[0].gold += gold;
            break;
        case 2:
            players[1].gold += gold;
            break;
    }
}

function log(s){
    logText = logText + s + "\n";
    disp.log(logText);
}

function procMove(diceValue){
    disp.horseHide(currentPlayerTurn, players[currentPlayerTurn-1].loc);  // 현재 플레이어의 기존 위치 말 표시를 가리기
    players[currentPlayerTurn-1].loc = players[currentPlayerTurn-1].loc + diceValue;
    if(players[currentPlayerTurn-1].loc > 12){  // 12 이상이면 출발점을 도착했거나 통과한 것이므로 월급 지급 처리
        playerGoldPlusMinus(currentPlayerTurn,landValues[0]);   // 월급 더하기
        players[currentPlayerTurn-1].loc = players[currentPlayerTurn-1].loc % 12;   
    }
    log(`플레이어 ${currentPlayerTurn} 의 현재 위치는 ${LANDS[players[currentPlayerTurn-1].loc-1]} 입니다.`);
    disp.horseShow(currentPlayerTurn, players[currentPlayerTurn-1].loc);  // 현재 플레이어의 말이 이동한 땅에 말 표시하기

    ////    플레이어가 이동한 땅이 구매 가능한 땅인 경우 처리
    if(landCanBuy.includes(players[currentPlayerTurn-1].loc)){    // 도착한 땅이 구매 가능한 땅이면
        players[currentPlayerTurn-1].lands.push(players[currentPlayerTurn-1].loc);  // 플레이어 1의 땅 배열에 추가
        ////    기존 구매 가능한 땅 배열에서 구매한 땅은 제거하기
        let cutLandIndex = landCanBuy.indexOf(players[currentPlayerTurn-1].loc);  // 방금 산 땅 번호로 구매 가능한 땅 배열의 해당 땅 index 구하기
        landCanBuy.splice(cutLandIndex,1); // 구한 인덱스 넣어서 배열에서 제외시키기. splice 함수용법 주의. slice 랑 헷갈림 주의.
        ////    구매한 땅들 상태창에 출력
        let sLands = "";
        for(let i=0;i<players[currentPlayerTurn-1].lands.length;i++){
            sLands = sLands + LANDS[players[currentPlayerTurn-1].lands[i]-1] + " ";   //배열 헷갈림 주의
            ////    보유한 땅을 색깔로도 표시처리
            let colorLandTag = document.getElementById("a"+players[currentPlayerTurn-1].lands[i]);
            colorLandTag.style.backgroundColor = players[currentPlayerTurn-1].color;
        }
        disp.showPlayerLand(currentPlayerTurn, sLands);
    }

    if(players[currentPlayerTurn-1].loc == 10){   // 국민연금에 걸리면 납부 처리
        visitFee = lands[players[currentPlayerTurn-1].loc-1].visitFee;

        // payGoldToBank(currentPlayerTurn, landValues[players[currentPlayerTurn-1].loc-1]);
        // log(`플레이어 ${currentPlayerTurn} 이 국민연금 ${landValues[players[currentPlayerTurn-1].loc-1]}원을 납부했습니다.`);
        payGoldToBank(currentPlayerTurn, visitFee);
        log(`플레이어 ${currentPlayerTurn} 이 국민연금 ${visitFee}원을 납부했습니다.`);
    }

    //todo
    // 땅 주인 찾기, 검색

    if(currentPlayerTurn == 1){    
        if(players[1].lands.includes(players[0].loc)){  // 상대의 땅에 걸리면 해당 땅 값을 상대에게 지불 처리
            payGoldToPlayer(1,2,landValues[players[0].loc-1]);
        }

    }
    if(currentPlayerTurn == 2){
        if(players[0].lands.includes(players[1].loc)){  // 상대의 땅에 걸리면 해당 땅 값을 상대에게 지불 처리
            payGoldToPlayer(2,1,landValues[players[1].loc-1]);
        }
    }
}