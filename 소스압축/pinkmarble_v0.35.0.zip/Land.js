class Land {
    number;         // 땅 번호
    name;           // 땅 이름
    desc;           // 설명
    baseColor;      // 기본 색상
    type;           // 땅 종류: 1:구매가능한 땅 , 2:시작, 3:무인도, 4:우주왕복선, 5:벌금 또는 세금 납부, 7:황금열쇠
    owner = 0;      // 소유자: 0:뱅크 , 숫자:유저번호

    ////    가격 관련 변수들
    landPurchasePrice;          // 땅 구입 가격
    vactionHomePurchasePrice;   // 별장 구입 가격
    buildingPurchasePrice;      // 빌딩 구입 가격
    hotelPurchasePrice;         // 호텔 구입 가격
    visitFee;       // 방문료
    bonus;          // 보너스

    constructor(number, name, visitFee, type){
        this.number = number;
        this.name = name;
        this.visitFee = visitFee;
        this.type = type;
    }

    static getPlayerLands(player,lands){
        let playerLands = [];
        for(let i=0;i<lands.length;i++){
            if(lands[i].owner == player.number){
                playerLands.push(lands[i]);
            }
        }
        return playerLands;
    }
}