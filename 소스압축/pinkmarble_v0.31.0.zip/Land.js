class Land {
    name;           // 땅 이름
    purchasePrice;  // 구입 가격
    desc;           // 설명
    baseColor;      // 기본 색상
    type;           // 땅 종류
    visitFee;       // 방문료
    owner = 0;      // 소유자: 0:뱅크 , 숫자:유저번호

    constructor(name, visitFee){
        this.name = name;
        this.visitFee = visitFee;
    }

}