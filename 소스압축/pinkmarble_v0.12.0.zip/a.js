const VERSION = "pinkmarble_v0.13.0";    // 핑크 마블 버전을 상수로
let versionTag; //버전 표시되는 p 태그를 (가르킬)저장 할 변수
let logTag; //택스트에어리어 태그를 (가르킬)저장 할 변수
let logText = ""; // 텍스트에어리어 내에 표현되는 텍스트를 계속 누적시킬 용도의 텍스트변수;
let btnDiceRollPlayer1, btnDiceRollPlayer2; // 이렇게 쭈욱 선언도 가능함
let currentPlayerTurn = 1;  // 현재 어떤 플레이어의 차례인지 표시하는 변수
let player1Loc = 1;  // 현재 플레이어 1 의 위치 값
let player2Loc = 1;  // 현재 플레이어 2 의 위치 값
let player1Gold = 100, player2Gold = 100;
let tagPlayer1Gold, tagPlayer2Gold; // 플레이어 골드 표시 태그를 가르킬 변수
const lands = [
    "시작",
    "고양",
    "창원",
    "무인도",
    "울산",
    "수원",
    "우주왕복선",
    "대구",
    "인천",
    "국민연금",
    "부산",
    "서울"
];

window.onload = function(){
    versionTag = document.getElementById('version_tag'); // 태그 변수에 태그 연결
    versionTag.innerHTML = VERSION; // 버전 태그 안의 html 공간에 버전 상수 값(버전명) 넣기
    logTag = document.getElementById('ta_log'); // 태그 변수에 태그 연결
    btnDiceRollPlayer1 = document.getElementById('btn_dice_roll_player1');  // 태그 변수에 태그 연결
    btnDiceRollPlayer2 = document.getElementById('btn_dice_roll_player2');  // 태그 변수에 태그 연결
    tagPlayer1Gold = document.getElementById('player_1_gold');  // 태그 변수에 태그 연결
    tagPlayer2Gold = document.getElementById('player_2_gold');  // 태그 변수에 태그 연결

    ////    게임 시작 되기 전 초기화 처리들 ////
    btnDiceRollPlayer2.disabled = true; //비활성화 처리
    tagPlayer1Gold.innerHTML = player1Gold + "원";  // 플레이어 1의 소지금 표시
    tagPlayer2Gold.innerHTML = player2Gold + "원";  // 플레이어 2의 소지금 표시
}

function dice(playerNumber){
    console.log("플레이어 "+playerNumber);
    let diceValue = Math.floor(Math.random()*6+1);
    console.log(diceValue);
    // 텍스트에어리어 태그는 해당 태그 변수에 .을 찍고 value 내장변수를 쓰면(우리가 정한 변수가 아닌 원래 내장된 변수 임)
    // 텍스트에어리어 안에 작성될 텍스트 칸을 가르킬 수 있게 됨.
    // 이렇게 가르킬 수 있게된 곳(이것도 사실 변수임. 뒤에서 클래스를 배우고나서 알게 될 객체의 멤버변수)에 숫자나 문자를 넣게되면( = 우변에 숫자나 문자 값을 대입하면 )
    // 해당 텍스트에어리어 태그 내에 글씨가 나오게 됨.
    // logTag.value = diceValue;

    // 텍스트를 좀 꾸며주려면 이렇게.. (변수에 다른 값을 넣으면 기존 값은 없어짐)
    // logTag.value = "주사위를 굴려 " + diceValue + "(이)가 나왔습니다.";

    // 1,3,6 일 때는 조사 '이' 가 표시되게 하고
    // 2,4,5 일 때는 조사 '가' 가 표시되게 하기
    let josa = "";
    switch(diceValue){
        case 1:
        case 3:
        case 6:
            josa = "이";
            break;
        case 2:
        case 4:
        case 5:
            josa = "가";
            break;
    }

    // n = n + 1; 숫자 1씩 누적시키는 식;
    // s = s + "야옹"; << 문자열 "야옹" 을 누적시키는 식
    logText = logText + "플레이어 " + playerNumber + "(이)가 주사위를 굴려 " + diceValue + " " + josa + " 나왔습니다.";
    logText = logText + "\n";   // \n은 일반 텍스트에서 엔터를 뜻하는 특수표식

    ////    플레이어 위치 처리  ////
    if(currentPlayerTurn == 1){
        player1Loc = player1Loc + diceValue;
        if(player1Loc > 12){
            // 12 이상이면 출발점을 도착했거나 통과한 것이므로 월급 지급 처리
            player1Gold = player1Gold + 20; // 월급 더하기
            tagPlayer1Gold.innerHTML = player1Gold + "원";  // 플레이어 1의 소지금 표시

            // 숙지! = 을 기준으로 연산은 우변부터 이뤄진다. (연산자 우선 순위)
            // % 연산자는 좌측 피연산자 값을 12로 나눈 나머지 값을 계산하는 식임. 그다음 = 으로 해서 좌변으로 그 값을 넘김 처리함.
            player1Loc = player1Loc % 12;   
        }
        logText = logText + "플레이어 " + playerNumber + "의 현재 위치는 " + lands[player1Loc-1] + " 입니다. \n";
    }
    if(currentPlayerTurn == 2){
        player2Loc = player2Loc + diceValue;
        if(player2Loc > 12){
            // 12 이상이면 출발점을 도착했거나 통과한 것이므로 월급 지급 처리
            player2Gold = player2Gold + 20; // 월급 더하기
            tagPlayer2Gold.innerHTML = player2Gold + "원";  // 플레이어 1의 소지금 표시

            // 숙지! = 을 기준으로 연산은 우변부터 이뤄진다. (연산자 우선 순위)
            // % 연산자는 좌측 피연산자 값을 12로 나눈 나머지 값을 계산하는 식임. 그다음 = 으로 해서 좌변으로 그 값을 넘김 처리함.
            player2Loc = player2Loc % 12;
        }        
        // logText = logText + "플레이어 " + playerNumber + "의 현재 위치는 " + player2Loc + " 입니다. \n";
        logText = logText + "플레이어 " + playerNumber + "의 현재 위치는 " + lands[player2Loc-1] + " 입니다. \n";
    }

    logTag.value = logText; //텍스트에어리어에 총 누적 텍스트를 표시하기

    // <꿀팁 코드>
    // 이렇게 하면 텍스트에어리어 내의 텍스트가 늘어나서 스크롤이 생길 경우
    // 자동으로 맨 아래로 스크롤이 됨
    // 즉, 이제 어떤 내용을 쭉 표시해도 계속 최신 내용을 자동으로 잘 확인 할 수 있게 됨
    logTag.scrollTop = logTag.scrollHeight;

    //// 플레이어 턴 넘김 처리  ////
    if(currentPlayerTurn == 1){   // 플레이어 1이 주사위를 다 굴린 후 처리들
        btnDiceRollPlayer1.disabled = true;     //비활성화 처리
        btnDiceRollPlayer2.disabled = false;    //활성화 처리
        currentPlayerTurn = 2;  // 현재 플레이어를 2로 바꿈
    } else if(currentPlayerTurn == 2) {    // 플레이어 2가 주사위를 다 굴린 후 처리들
        btnDiceRollPlayer1.disabled = false;    //활성화 처리
        btnDiceRollPlayer2.disabled = true;     //비활성화 처리
        currentPlayerTurn = 1;  // 현재 플레이어를 2로 바꿈
    } else {
        console.log("현재 플레이어 값 에러 !!!");
    }
}