const VERSION = "pinkmarble_v0.24.0";    // 핑크 마블 버전을 상수로
const LANDS = ["시작","고양","창원","무인도","울산","수원","우주왕복선","대구","인천","국민연금","부산","서울"];

class Player {
    gold = 100; // 시작 돈
    loc = 1;    // 시작점
    horse;      // 말 모양(이모지)
    color;      // 플레이어 색상
    constructor(horse,color){
        this.horse = horse;
        this.color = color;
    }
}

let players = [];    // 플레이어 객체 배열

let tagVersion;         //버전 표시되는 p 태그를 (가르킬)저장 할 변수
let tagLog;             //택스트에어리어 태그를 (가르킬)저장 할 변수
let tagPlayer1Gold, tagPlayer2Gold;     // 플레이어 골드 표시 태그를 가르킬 변수
let tagPlayer1Land, tagPlayer2Land;     // 플레이어 땅 표시 태그를 가르킬 변수

let btnDiceRollPlayer1, btnDiceRollPlayer2; // 이렇게 쭈욱 선언도 가능함

let logText = "";       // 텍스트에어리어 내에 표현되는 텍스트를 계속 누적시킬 용도의 텍스트변수;
let currentPlayerTurn = 1;  // 현재 어떤 플레이어의 차례인지 표시하는 변수
let player1Loc = 1, player2Loc = 1;     // 현재 플레이어 1, 2 의 위치 값
let player1Lands = [];
let player2Lands = [];
let landCanBuy = [2,3,5,6,8,9,11,12];   // 구매 가능한 땅 번호 배열
let landValues = [20,10,20,0,30,40,30,50,60,30,80,100];   // 땅 순서대로 땅값 또는 내거나 받을 돈을 나열한 배열

window.onload = function(){
    init(); //각종 초기화 처리들
    displayPlayersGold();
}

function dice(playerNumber){
    let diceValue = Math.floor(Math.random()*6+1);
    log(`플레이어 ${playerNumber}(이)가 주사위를 굴려 ${diceValue} (이)가 나왔습니다.`);
    ////    플레이어 위치 처리  ////
    if(currentPlayerTurn == 1){
        ////    기존 플레이어 1 말 표시를 가리기
        let playerHorse1BeforeParentTag = document.getElementById('a'+player1Loc);
        let playerHorse1BeforeTag = playerHorse1BeforeParentTag.getElementsByTagName('div');
        playerHorse1BeforeTag[0].style.visibility = "hidden";

        player1Loc = player1Loc + diceValue;
        if(player1Loc > 12){    // 12 이상이면 출발점을 도착했거나 통과한 것이므로 월급 지급 처리
            playerGoldPlusMinus(1,landValues[0]);  // 월급 더하기
            player1Loc = player1Loc % 12;   
        }
        log(`플레이어 ${playerNumber} 의 현재 위치는 ${LANDS[player1Loc-1]} 입니다.`);
        
        ////    플레이어 1 말이 이동한 땅에 말 표시하기
        let playerHorse1AfterParentTag = document.getElementById('a'+player1Loc);
        let playerHorse1AfterTag = playerHorse1AfterParentTag.getElementsByTagName('div');
        playerHorse1AfterTag[0].style.visibility = "visible";

        ////    플레이어가 이동한 땅이 구매 가능한 땅인 경우 처리
        if(landCanBuy.includes(player1Loc)){    // 도착한 땅이 구매 가능한 땅이면
            player1Lands.push(player1Loc);  // 플레이어 1의 땅 배열에 추가
            ////    기존 구매 가능한 땅 배열에서 구매한 땅은 제거하기
            let cutLandIndex = landCanBuy.indexOf(player1Loc);  // 방금 산 땅 번호로 구매 가능한 땅 배열의 해당 땅 index 구하기
            landCanBuy.splice(cutLandIndex,1); // 구한 인덱스 넣어서 배열에서 제외시키기. splice 함수용법 주의. slice 랑 헷갈림 주의.
            ////    구매한 땅들 상태창에 출력
            let sLands = "";
            for(let i=0;i<player1Lands.length;i++){
                sLands = sLands + LANDS[player1Lands[i]-1] + " ";   //배열 헷갈림 주의
                ////    보유한 땅을 색깔로도 표시처리
                let colorLandTag = document.getElementById("a"+player1Lands[i]);
                colorLandTag.style.backgroundColor = "red";
            }
            tagPlayer1Land.innerHTML = sLands;
        }
        if(player2Lands.includes(player1Loc)){  // 상대의 땅에 걸리면 해당 땅 값을 상대에게 지불 처리
            payGoldToPlayer(1,2,landValues[player1Loc-1]);
        }
        if(player1Loc == 10){   // 국민연금에 걸리면 납부 처리
            payGoldToBank(currentPlayerTurn, landValues[player1Loc-1]);
            log(`플레이어 1이 국민연금 ${landValues[player1Loc-1]}원을 납부했습니다.`);
        }
    }
    if(currentPlayerTurn == 2){
        ////    기존 플레이어 2 말 표시를 가리기 (주의. 플레이어 2는 두번째 div이므로 index 1로 접근해야함)
        let playerHorse2BeforeParentTag = document.getElementById('a'+player2Loc);
        let playerHorse2BeforeTag = playerHorse2BeforeParentTag.getElementsByTagName('div');
        playerHorse2BeforeTag[1].style.visibility = "hidden";        

        player2Loc = player2Loc + diceValue;
        if(player2Loc > 12){    // 12 이상이면 출발점을 도착했거나 통과한 것이므로 월급 지급 처리
            playerGoldPlusMinus(2,landValues[0]);  // 월급 더하기
            player2Loc = player2Loc % 12;
        }        
        log(`플레이어 ${playerNumber} 의 현재 위치는 ${LANDS[player2Loc-1]} 입니다.`);
        ////    플레이어 2 말이 이동한 땅에 말 표시하기 (주의. 플레이어 2는 두번째 div이므로 index 1로 접근해야함)
        let playerHorse2AfterParentTag = document.getElementById('a'+player2Loc);
        let playerHorse2AfterTag = playerHorse2AfterParentTag.getElementsByTagName('div');
        playerHorse2AfterTag[1].style.visibility = "visible";        
        ////    플레이어가 이동한 땅이 구매 가능한 땅인 경우 처리
        if(landCanBuy.includes(player2Loc)){    // 도착한 땅이 구매 가능한 땅이면
            player2Lands.push(player2Loc);  // 플레이어 1의 땅 배열에 추가
            ////    기존 구매 가능한 땅 배열에서 구매한 땅은 제거하기
            let cutLandIndex = landCanBuy.indexOf(player2Loc);  // 방금 산 땅 번호로 구매 가능한 땅 배열의 해당 땅 index 구하기
            landCanBuy.splice(cutLandIndex,1); // 구한 인덱스 넣어서 배열에서 제외시키기. splice 함수용법 주의. slice 랑 헷갈림 주의.
            ////    구매한 땅들 상태창에 출력
            let sLands = "";
            for(let i=0;i<player2Lands.length;i++){
                sLands = sLands + LANDS[player2Lands[i]-1] + " ";   //배열 헷갈림 주의
                ////    보유한 땅을 색깔로도 표시처리
                let colorLandTag = document.getElementById("a"+player2Lands[i]);
                colorLandTag.style.backgroundColor = "blue";                
            }
            tagPlayer2Land.innerHTML = sLands;
        }        
        if(player1Lands.includes(player2Loc)){  // 상대의 땅에 걸리면 해당 땅 값을 상대에게 지불 처리
            payGoldToPlayer(2,1,landValues[player2Loc-1]);
        }
        if(player2Loc == 10){   // 국민연금에 걸리면 납부 처리
            payGoldToBank(currentPlayerTurn, landValues[player2Loc-1]);
            log(`플레이어 2가 국민연금 ${landValues[player2Loc-1]}원을 납부했습니다.`);
        }
    }
    displayPlayersGold();   // 금액 표시 갱신
    procTurnPass(currentPlayerTurn);    // 플레이어 턴 넘김 처리
    checkGameover();
}

function init(){
    tagVersion = document.getElementById('version_tag'); // 태그 변수에 태그 연결
    tagLog = document.getElementById('ta_log'); // 태그 변수에 태그 연결
    tagPlayer1Gold = document.getElementById('player_1_gold');  // 태그 변수에 태그 연결
    tagPlayer2Gold = document.getElementById('player_2_gold');  // 태그 변수에 태그 연결
    tagPlayer1Land = document.getElementById('player_1_land');  // 태그 변수에 태그 연결
    tagPlayer2Land = document.getElementById('player_2_land');  // 태그 변수에 태그 연결
    btnDiceRollPlayer1 = document.getElementById('btn_dice_roll_player1');  // 태그 변수에 태그 연결
    btnDiceRollPlayer2 = document.getElementById('btn_dice_roll_player2');  // 태그 변수에 태그 연결
    
    tagVersion.innerHTML = VERSION; // 버전 태그 안의 html 공간에 버전 상수 값(버전명) 넣기
    btnDiceRollPlayer2.disabled = true; //비활성화 처리

    players.push(new Player('😻','red'));
    players.push(new Player('🐺','blue'));
}

function displayPlayersGold(){
    tagPlayer1Gold.innerHTML = players[0].gold + "원";  // 플레이어 1의 소지금 표시
    tagPlayer2Gold.innerHTML = players[1].gold + "원";  // 플레이어 2의 소지금 표시    
}

function checkGameover(){
    // if(player1Gold<=0){
    if(players[0].gold<=0){
        log("게임오버! 플레이어 2가 이겼습니다.");
        displayDiceBtnAllDisable();
    }         
    // if(player2Gold<=0){
    if(players[1].gold<=0){
        log("게임오버! 플레이어 1이 이겼습니다.");
        displayDiceBtnAllDisable();
    }         
}

function log(s){
    logText = logText + s + "\n";
    tagLog.value = logText; //텍스트에어리어에 총 누적 텍스트를 표시하기
    tagLog.scrollTop = tagLog.scrollHeight; // 자동 스크롤 처리    
}

function procTurnPass(playerNumber){
    if(playerNumber == 1){   // 플레이어 1이 주사위를 다 굴린 후 처리들
        btnDiceRollPlayer1.disabled = true;     //비활성화 처리
        btnDiceRollPlayer2.disabled = false;    //활성화 처리
        currentPlayerTurn = 2;  // 현재 플레이어를 2로 바꿈
    } else if(playerNumber == 2) {    // 플레이어 2가 주사위를 다 굴린 후 처리들
        btnDiceRollPlayer1.disabled = false;    //활성화 처리
        btnDiceRollPlayer2.disabled = true;     //비활성화 처리
        currentPlayerTurn = 1;  // 현재 플레이어를 2로 바꿈
    }
}

function displayDiceBtnAllDisable(){
    btnDiceRollPlayer1.disabled = true;    //활성화 처리
    btnDiceRollPlayer2.disabled = true;     //비활성화 처리    
}

function payGoldToBank(player,gold){    // 은행에 납부는 플레이어 골드 함수의 골드를 - 로 바꿔 전달해서 처리함.
    playerGoldPlusMinus(player,-gold);
}

function payGoldToPlayer(fromPlayer,toPlayer,gold){ // 주의: 지불할 금액은 양수로 넣게했음.
    playerGoldPlusMinus(fromPlayer,-gold);
    playerGoldPlusMinus(toPlayer,gold);
}

function playerGoldPlusMinus(player,gold){
    switch(player){
        case 1:
            players[0].gold += gold;
            break;
        case 2:
            players[1].gold += gold;
            break;
    }
}

// 아직 개발 x
function displayHorseHide(player){
    
}
function displayHorseShow(player){

}