const VERSION = "pinkmarble_v0.16.0";    // 핑크 마블 버전을 상수로
let versionTag; //버전 표시되는 p 태그를 (가르킬)저장 할 변수
let logTag; //택스트에어리어 태그를 (가르킬)저장 할 변수
let logText = ""; // 텍스트에어리어 내에 표현되는 텍스트를 계속 누적시킬 용도의 텍스트변수;
let btnDiceRollPlayer1, btnDiceRollPlayer2; // 이렇게 쭈욱 선언도 가능함
let currentPlayerTurn = 1;  // 현재 어떤 플레이어의 차례인지 표시하는 변수
let player1Loc = 1;  // 현재 플레이어 1 의 위치 값
let player2Loc = 1;  // 현재 플레이어 2 의 위치 값
let player1Gold = 100, player2Gold = 100;
let tagPlayer1Gold, tagPlayer2Gold; // 플레이어 골드 표시 태그를 가르킬 변수
let player1Lands = [];
let player2Lands = [];
let landCanBuy = [2,3,5,6,8,9,11,12];   // 구매 가능한 땅 번호 배열
let landValues = [20,10,20,0,30,40,30,50,60,20,80,100];   // 땅 순서대로 땅값 또는 내거나 받을 돈을 나열한 배열
let tagPlayer1Land, tagPlayer2Land; // 플레이어 땅 표시 태그를 가르킬 변수
const lands = [
    "시작",
    "고양",
    "창원",
    "무인도",
    "울산",
    "수원",
    "우주왕복선",
    "대구",
    "인천",
    "국민연금",
    "부산",
    "서울"
];

window.onload = function(){
    versionTag = document.getElementById('version_tag'); // 태그 변수에 태그 연결
    versionTag.innerHTML = VERSION; // 버전 태그 안의 html 공간에 버전 상수 값(버전명) 넣기
    logTag = document.getElementById('ta_log'); // 태그 변수에 태그 연결
    btnDiceRollPlayer1 = document.getElementById('btn_dice_roll_player1');  // 태그 변수에 태그 연결
    btnDiceRollPlayer2 = document.getElementById('btn_dice_roll_player2');  // 태그 변수에 태그 연결
    tagPlayer1Gold = document.getElementById('player_1_gold');  // 태그 변수에 태그 연결
    tagPlayer2Gold = document.getElementById('player_2_gold');  // 태그 변수에 태그 연결
    tagPlayer1Land = document.getElementById('player_1_land');  // 태그 변수에 태그 연결
    tagPlayer2Land = document.getElementById('player_2_land');  // 태그 변수에 태그 연결

    ////    게임 시작 되기 전 초기화 처리들 ////
    btnDiceRollPlayer2.disabled = true; //비활성화 처리
    tagPlayer1Gold.innerHTML = player1Gold + "원";  // 플레이어 1의 소지금 표시
    tagPlayer2Gold.innerHTML = player2Gold + "원";  // 플레이어 2의 소지금 표시
}

function dice(playerNumber){
    console.log("플레이어 "+playerNumber);
    let diceValue = Math.floor(Math.random()*6+1);
    console.log(diceValue);
    // 텍스트에어리어 태그는 해당 태그 변수에 .을 찍고 value 내장변수를 쓰면(우리가 정한 변수가 아닌 원래 내장된 변수 임)
    // 텍스트에어리어 안에 작성될 텍스트 칸을 가르킬 수 있게 됨.
    // 이렇게 가르킬 수 있게된 곳(이것도 사실 변수임. 뒤에서 클래스를 배우고나서 알게 될 객체의 멤버변수)에 숫자나 문자를 넣게되면( = 우변에 숫자나 문자 값을 대입하면 )
    // 해당 텍스트에어리어 태그 내에 글씨가 나오게 됨.
    // logTag.value = diceValue;

    // 텍스트를 좀 꾸며주려면 이렇게.. (변수에 다른 값을 넣으면 기존 값은 없어짐)
    // logTag.value = "주사위를 굴려 " + diceValue + "(이)가 나왔습니다.";

    // 1,3,6 일 때는 조사 '이' 가 표시되게 하고
    // 2,4,5 일 때는 조사 '가' 가 표시되게 하기
    let josa = "";
    switch(diceValue){
        case 1:
        case 3:
        case 6:
            josa = "이";
            break;
        case 2:
        case 4:
        case 5:
            josa = "가";
            break;
    }

    // n = n + 1; 숫자 1씩 누적시키는 식;
    // s = s + "야옹"; << 문자열 "야옹" 을 누적시키는 식
    logText = logText + "플레이어 " + playerNumber + "(이)가 주사위를 굴려 " + diceValue + " " + josa + " 나왔습니다.";
    logText = logText + "\n";   // \n은 일반 텍스트에서 엔터를 뜻하는 특수표식

    ////    플레이어 위치 처리  ////
    if(currentPlayerTurn == 1){
        ////    기존 플레이어 1 말 표시를 가리기
        let playerHorse1BeforeParentTag = document.getElementById('a'+player1Loc);
        let playerHorse1BeforeTag = playerHorse1BeforeParentTag.getElementsByTagName('div');
        playerHorse1BeforeTag[0].style.visibility = "hidden";

        player1Loc = player1Loc + diceValue;
        if(player1Loc > 12){
            // 12 이상이면 출발점을 도착했거나 통과한 것이므로 월급 지급 처리
            player1Gold = player1Gold + 20; // 월급 더하기
            tagPlayer1Gold.innerHTML = player1Gold + "원";  // 플레이어 1의 소지금 표시

            // 숙지! = 을 기준으로 연산은 우변부터 이뤄진다. (연산자 우선 순위)
            // % 연산자는 좌측 피연산자 값을 12로 나눈 나머지 값을 계산하는 식임. 그다음 = 으로 해서 좌변으로 그 값을 넘김 처리함.
            player1Loc = player1Loc % 12;   
        }
        logText = logText + "플레이어 " + playerNumber + "의 현재 위치는 " + lands[player1Loc-1] + " 입니다. \n";

        ////    플레이어 1 말이 이동한 땅에 말 표시하기
        let playerHorse1AfterParentTag = document.getElementById('a'+player1Loc);
        let playerHorse1AfterTag = playerHorse1AfterParentTag.getElementsByTagName('div');
        playerHorse1AfterTag[0].style.visibility = "visible";

        ////    플레이어가 이동한 땅이 구매 가능한 땅인 경우 처리
        if(landCanBuy.includes(player1Loc)){    // 도착한 땅이 구매 가능한 땅이면
            console.log("구매 가능한 땅에 도착 함. 땅번호:"+player1Loc);

            player1Lands.push(player1Loc);  // 플레이어 1의 땅 배열에 추가

            ////    기존 구매 가능한 땅 배열에서 구매한 땅은 제거하기
            let cutLandIndex = landCanBuy.indexOf(player1Loc);  // 방금 산 땅 번호로 구매 가능한 땅 배열의 해당 땅 index 구하기
            landCanBuy.splice(cutLandIndex,1); // 구한 인덱스 넣어서 배열에서 제외시키기. splice 함수용법 주의. slice 랑 헷갈림 주의.

            console.log("구매가능한 땅들:"+landCanBuy);  //임시로그
            console.log("플레이어1의 땅들:"+player1Lands);  //임시로그

            ////    구매한 땅들 상태창에 출력
            let sLands = "";
            for(let i=0;i<player1Lands.length;i++){
                sLands = sLands + lands[player1Lands[i]-1] + " ";   //배열 헷갈림 주의
            }
            tagPlayer1Land.innerHTML = sLands;
        }

        ////    상대의 땅에 걸리면 해당 땅 값을 상대에게 지불 처리
        if(player2Lands.includes(player1Loc)){
            console.log("상대에게 땅값 내야함. 낼 돈:"+landValues[player1Loc-1]+"원");
            player1Gold = player1Gold - landValues[player1Loc-1];   //돈 빼고
            player2Gold = player2Gold + landValues[player1Loc-1];   //돈 더하고
            tagPlayer1Gold.innerHTML = player1Gold + "원";  // 플레이어 1의 소지금 표시
            tagPlayer2Gold.innerHTML = player2Gold + "원";  // 플레이어 2의 소지금 표시
        }
        
    }
    if(currentPlayerTurn == 2){
        ////    기존 플레이어 2 말 표시를 가리기 (주의. 플레이어 2는 두번째 div이므로 index 1로 접근해야함)
        let playerHorse2BeforeParentTag = document.getElementById('a'+player2Loc);
        let playerHorse2BeforeTag = playerHorse2BeforeParentTag.getElementsByTagName('div');
        playerHorse2BeforeTag[1].style.visibility = "hidden";        

        player2Loc = player2Loc + diceValue;
        if(player2Loc > 12){
            // 12 이상이면 출발점을 도착했거나 통과한 것이므로 월급 지급 처리
            player2Gold = player2Gold + 20; // 월급 더하기
            tagPlayer2Gold.innerHTML = player2Gold + "원";  // 플레이어 1의 소지금 표시

            // 숙지! = 을 기준으로 연산은 우변부터 이뤄진다. (연산자 우선 순위)
            // % 연산자는 좌측 피연산자 값을 12로 나눈 나머지 값을 계산하는 식임. 그다음 = 으로 해서 좌변으로 그 값을 넘김 처리함.
            player2Loc = player2Loc % 12;
        }        
        // logText = logText + "플레이어 " + playerNumber + "의 현재 위치는 " + player2Loc + " 입니다. \n";
        logText = logText + "플레이어 " + playerNumber + "의 현재 위치는 " + lands[player2Loc-1] + " 입니다. \n";

        ////    플레이어 2 말이 이동한 땅에 말 표시하기 (주의. 플레이어 2는 두번째 div이므로 index 1로 접근해야함)
        let playerHorse2AfterParentTag = document.getElementById('a'+player2Loc);
        let playerHorse2AfterTag = playerHorse2AfterParentTag.getElementsByTagName('div');
        playerHorse2AfterTag[1].style.visibility = "visible";        

        ////    플레이어가 이동한 땅이 구매 가능한 땅인 경우 처리
        if(landCanBuy.includes(player2Loc)){    // 도착한 땅이 구매 가능한 땅이면
            console.log("구매 가능한 땅에 도착 함. 땅번호:"+player2Loc);

            player2Lands.push(player2Loc);  // 플레이어 1의 땅 배열에 추가

            ////    기존 구매 가능한 땅 배열에서 구매한 땅은 제거하기
            let cutLandIndex = landCanBuy.indexOf(player2Loc);  // 방금 산 땅 번호로 구매 가능한 땅 배열의 해당 땅 index 구하기
            landCanBuy.splice(cutLandIndex,1); // 구한 인덱스 넣어서 배열에서 제외시키기. splice 함수용법 주의. slice 랑 헷갈림 주의.

            console.log("구매가능한 땅들:"+landCanBuy);  //임시로그
            console.log("플레이어2의 땅들:"+player2Lands);  //임시로그

            ////    구매한 땅들 상태창에 출력
            // tagPlayer1Land.innerHTML = player1Lands;
            let sLands = "";
            for(let i=0;i<player2Lands.length;i++){
                sLands = sLands + lands[player2Lands[i]-1] + " ";   //배열 헷갈림 주의
            }
            tagPlayer2Land.innerHTML = sLands;
        }        

        ////    상대의 땅에 걸리면 해당 땅 값을 상대에게 지불 처리
        if(player1Lands.includes(player2Loc)){
            console.log("상대에게 땅값 내야함. 낼 돈:"+landValues[player2Loc-1]+"원");
            player2Gold = player2Gold - landValues[player2Loc-1];   //돈 빼고
            player1Gold = player1Gold + landValues[player2Loc-1];   //돈 더하고
            tagPlayer1Gold.innerHTML = player1Gold + "원";  // 플레이어 1의 소지금 표시
            tagPlayer2Gold.innerHTML = player2Gold + "원";  // 플레이어 2의 소지금 표시
        }
    }

    logTag.value = logText; //텍스트에어리어에 총 누적 텍스트를 표시하기

    // <꿀팁 코드>
    // 이렇게 하면 텍스트에어리어 내의 텍스트가 늘어나서 스크롤이 생길 경우
    // 자동으로 맨 아래로 스크롤이 됨
    // 즉, 이제 어떤 내용을 쭉 표시해도 계속 최신 내용을 자동으로 잘 확인 할 수 있게 됨
    logTag.scrollTop = logTag.scrollHeight;

    //// 플레이어 턴 넘김 처리  ////
    if(currentPlayerTurn == 1){   // 플레이어 1이 주사위를 다 굴린 후 처리들
        btnDiceRollPlayer1.disabled = true;     //비활성화 처리
        btnDiceRollPlayer2.disabled = false;    //활성화 처리
        currentPlayerTurn = 2;  // 현재 플레이어를 2로 바꿈
    } else if(currentPlayerTurn == 2) {    // 플레이어 2가 주사위를 다 굴린 후 처리들
        btnDiceRollPlayer1.disabled = false;    //활성화 처리
        btnDiceRollPlayer2.disabled = true;     //비활성화 처리
        currentPlayerTurn = 1;  // 현재 플레이어를 2로 바꿈
    } else {
        console.log("현재 플레이어 값 에러 !!!");
    }
}