const VERSION = "pinkmarble_v0.7.0";    // 핑크 마블 버전을 상수로
let versionTag;

alert('핑크마블 !!!');

window.onload = function(){
    versionTag = document.getElementById('version_tag');
    versionTag.innerHTML = VERSION; // 버전 태그 안의 html 공간에 버전 상수 값(버전명) 넣기
}