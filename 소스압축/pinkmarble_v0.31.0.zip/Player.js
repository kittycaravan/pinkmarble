class Player {
    gold = 100; // 시작 돈
    loc = 1;    // 시작점
    horse;      // 말 모양(이모지)
    color;      // 플레이어 색상
    lands = [];      // 플레이어 보유 땅 배열. 주의 lands; 라고 하면 안됨. 배열임을 꼭 초기화 해줘야함. include 함수 등 부분에서 에러남.
    constructor(horse,color){
        this.horse = horse;
        this.color = color;
    }
}