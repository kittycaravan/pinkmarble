class Land {
    name;           // 땅 이름
    desc;           // 설명
    baseColor;      // 기본 색상
    type;           // 땅 종류
    owner = 0;      // 소유자: 0:뱅크 , 숫자:유저번호

    ////    가격 관련 변수들
    landPurchasePrice;          // 땅 구입 가격
    vactionHomePurchasePrice;   // 별장 구입 가격
    buildingPurchasePrice;      // 빌딩 구입 가격
    hotelPurchasePrice;         // 호텔 구입 가격
    visitFee;       // 방문료
    bonus;          // 보너스

    constructor(name, visitFee){
        this.name = name;
        this.visitFee = visitFee;
    }


}