const VERSION = "pinkmarble_v0.33.0";
const LANDS = ["시작","고양","창원","무인도","울산","수원","우주왕복선","대구","인천","국민연금","부산","서울"];

let players = [];    // 플레이어 객체 배열
let disp;   // 디스플레이 객체
let lands = []; // 땅 객체 배열

let logText = "";       // 텍스트에어리어 내에 표현되는 텍스트를 계속 누적시킬 용도의 텍스트변수;
let currentPlayerTurn = 1;  // 현재 어떤 플레이어의 차례인지 표시하는 변수
let player1Lands = [];
let player2Lands = [];
let landCanBuy = [2,3,5,6,8,9,11,12];   // 구매 가능한 땅 번호 배열
let landValues = [20,10,20,0,30,40,30,50,60,30,80,100];   // 땅 순서대로 땅값 또는 내거나 받을 돈을 나열한 배열

window.onload = function(){
    init(); //각종 초기화 처리들
    disp.displayPlayersGold(players);
}

function dice(){
    let diceValue = Math.floor(Math.random()*6+1);
    log(`플레이어 ${currentPlayerTurn}(이)가 주사위를 굴려 ${diceValue} (이)가 나왔습니다.`);

    procMove(diceValue);    // 나온 주사위 값을 전달하고 이동으로 인한 모든 처리를 수행

    disp.displayPlayersGold(players);   // 금액 표시 갱신
    procTurnPass(currentPlayerTurn);    // 플레이어 턴 넘김 처리
    checkGameover();
}

function init(){
    // 땅 종류: 1:구매가능한 땅 , 2:시작, 3:무인도, 4:우주왕복선, 5:벌금 또는 세금 납부, 7:황금열쇠
    lands.push(new Land(1,"시작",20,2));
    lands.push(new Land(2,"고양",10,1));
    lands.push(new Land(3,"창원",20,1));
    lands.push(new Land(4,"무인도",0,3));
    lands.push(new Land(5,"울산",30,1));
    lands.push(new Land(6,"수원",40,1));
    lands.push(new Land(7,"우주왕복선",0,4));
    lands.push(new Land(8,"대구",50,1));
    lands.push(new Land(9,"인천",60,1));
    lands.push(new Land(10,"국민연금",30,5));
    lands.push(new Land(11,"부산",80,1));
    lands.push(new Land(12,"서울",100,1));
    disp = new Disp();
    disp.init();
    players.push(new Player(1,'😻','red'));
    players.push(new Player(2,'🐺','blue'));
}

function checkGameover(){
    if(players[0].gold<=0){
        disp.diceBtnAllDisable();
        log("게임오버! 플레이어 2가 이겼습니다.");
    }         
    if(players[1].gold<=0){
        disp.diceBtnAllDisable();
        log("게임오버! 플레이어 1이 이겼습니다.");
    }         
}

function procTurnPass(playerNumber){
    if(playerNumber == 1){   // 플레이어 1이 주사위를 다 굴린 후 처리들
        currentPlayerTurn = 2;  // 현재 플레이어를 2로 바꿈
    } else if(playerNumber == 2) {    // 플레이어 2가 주사위를 다 굴린 후 처리들
        currentPlayerTurn = 1;  // 현재 플레이어를 2로 바꿈
    }
    disp.diceBtnToggle(currentPlayerTurn);
}

function payGoldToBank(player,gold){    // 은행에 납부는 플레이어 골드 함수의 골드를 - 로 바꿔 전달해서 처리함.
    playerGoldPlusMinus(player,-gold);
}

function payGoldToPlayer(fromPlayer,toPlayer,gold){ // 주의: 지불할 금액은 양수로 넣게했음.
    playerGoldPlusMinus(fromPlayer,-gold);
    playerGoldPlusMinus(toPlayer,gold);
}

function playerGoldPlusMinus(player,gold){
    switch(player){
        case 1:
            players[0].gold += gold;
            break;
        case 2:
            players[1].gold += gold;
            break;
    }
}

function log(s){
    logText = logText + s + "\n";
    disp.log(logText);
}

function procMove(diceValue){
    disp.horseHide(currentPlayerTurn, players[currentPlayerTurn-1].loc);  // 현재 플레이어의 기존 위치 말 표시를 가리기
    players[currentPlayerTurn-1].loc = players[currentPlayerTurn-1].loc + diceValue;
    if(players[currentPlayerTurn-1].loc > 12){  // 12 이상이면 출발점을 도착했거나 통과한 것이므로 월급 지급 처리
        let bonus = lands[0].visitFee;
        playerGoldPlusMinus(currentPlayerTurn,bonus);   // 월급 더하기
        players[currentPlayerTurn-1].loc = players[currentPlayerTurn-1].loc % 12;   
        log(`플레이어 ${currentPlayerTurn} 이(가) 보너스 ${bonus}원을 지급받았습니다.`);
    }
    log(`플레이어 ${currentPlayerTurn} 의 현재 위치는 ${lands[players[currentPlayerTurn-1].loc-1].name} 입니다.`);
    disp.horseShow(currentPlayerTurn, players[currentPlayerTurn-1].loc);  // 현재 플레이어의 말이 이동한 땅에 말 표시하기

    checkLand();    // 도착한 땅에 대한 검사 및 처리

    uiUpdate();
}

function checkLand(){
    const land = lands[players[currentPlayerTurn-1].loc-1];
    const landType = land.type;
    switch(landType){
        case 1: //  구매가능한 땅
            if(land.owner == 0){
                log(`[ 빈땅에 도착 ]`);
                land.owner = currentPlayerTurn; // 땅 소유주를 현재 플레이어로 변경
                log(`[ 이제 이 땅은 플레이어 ${currentPlayerTurn} 의 것입니다 !!! ]`);
            } else {    // 다른 유저 또는 내 땅인지 체크
                if(land.owner == currentPlayerTurn){    // 내 땅이면
                    log('[ 휴 ~ 내 땅이네용 ~ ]');
                } else {    // 남의 땅이면.. 돈 물을 준비..
                    log('[ 헉! 남의 땅이네! 돈 물을 준비.. ]');
                    payGoldToPlayer(currentPlayerTurn,land.owner,land.visitFee);
                }
            }
            break;
        case 2: //  시작
            break;
        case 3: //  무인도
            log('[아이공 무인도에 걸렸네용 ~]');
            break;
        case 4: //  우주왕복선
            log('[ *** 우주왕복선 !!! *** ]');
            break;
        case 5: //  벌금
            log('[ 피 같은 세금 =ㅅ= ]');
            let fee = lands[players[currentPlayerTurn-1].loc-1].visitFee;
            payGoldToBank(currentPlayerTurn, fee);
            log(`플레이어 ${currentPlayerTurn} 이 ${lands[players[currentPlayerTurn-1].loc-1].name} ${fee}원을 납부했습니다.`);
            break;
        case 7: //  황금열쇠
            break;
    }
}

function uiUpdate(){
    disp.showPlayerLand(players, lands);
}