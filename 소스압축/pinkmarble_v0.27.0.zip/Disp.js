class Disp {

    tagVersion;         // 버전 표시되는 p 태그를 (가르킬)저장 할 변수
    tagLog;             // 택스트에어리어 태그를 (가르킬)저장 할 변수
    tagPlayer1Gold;     // 플레이어 골드 표시 태그를 가르킬 변수
    tagPlayer2Gold;     // 플레이어 골드 표시 태그를 가르킬 변수
    tagPlayer1Land;     // 플레이어 땅 표시 태그를 가르킬 변수
    tagPlayer2Land;     // 플레이어 땅 표시 태그를 가르킬 변수
    btnDiceRollPlayer1;
    btnDiceRollPlayer2;

    constructor(){
    }

    init(){
        this.tagVersion = document.getElementById('version_tag');                    // 태그 변수에 태그 연결
        this.tagLog = document.getElementById('ta_log');                             // 태그 변수에 태그 연결
        this.tagPlayer1Gold = document.getElementById('player_1_gold');              // 태그 변수에 태그 연결
        this.tagPlayer2Gold = document.getElementById('player_2_gold');              // 태그 변수에 태그 연결
        this.tagPlayer1Land = document.getElementById('player_1_land');              // 태그 변수에 태그 연결
        this.tagPlayer2Land = document.getElementById('player_2_land');              // 태그 변수에 태그 연결
        this.btnDiceRollPlayer1 = document.getElementById('btn_dice_roll_player1');  // 태그 변수에 태그 연결
        this.btnDiceRollPlayer2 = document.getElementById('btn_dice_roll_player2');  // 태그 변수에 태그 연결        

        this.tagVersion.innerHTML = VERSION; // 버전 태그 안의 html 공간에 버전 상수 값(버전명) 넣기
        this.btnDiceRollPlayer2.disabled = true; //비활성화 처리
    }

    log(logText){
        this.tagLog.value = logText; //텍스트에어리어에 총 누적 텍스트를 표시하기
        this.tagLog.scrollTop = this.tagLog.scrollHeight; // 자동 스크롤 처리    
    }    

    displayPlayersGold(players){
        this.tagPlayer1Gold.innerHTML = players[0].gold + "원";  // 플레이어 1의 소지금 표시
        this.tagPlayer2Gold.innerHTML = players[1].gold + "원";  // 플레이어 2의 소지금 표시    
    }

    showPlayerLand(player, sLands){
        switch(player){
            case 1:
                this.tagPlayer1Land.innerHTML = sLands;
                break;
            case 2:
                this.tagPlayer2Land.innerHTML = sLands;
                break;
        }
    }

    diceBtnAllDisable(){
        this.btnDiceRollPlayer1.disabled = true;    //활성화 처리
        this.btnDiceRollPlayer2.disabled = true;     //비활성화 처리    
    }
    diceBtnToggle(nextPlayer){
        switch(nextPlayer){
            case 1:
                this.btnDiceRollPlayer1.disabled = false;    //활성화 처리
                this.btnDiceRollPlayer2.disabled = true;     //비활성화 처리                
                break;
            case 2:
                this.btnDiceRollPlayer1.disabled = true;     //비활성화 처리
                this.btnDiceRollPlayer2.disabled = false;    //활성화 처리
                break;
        }
 
    }
}